import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AddReplyPage } from './add-reply';

@NgModule({
  declarations: [
    AddReplyPage,
  ],
  imports: [
    IonicPageModule.forChild(AddReplyPage),
  ],
})
export class AddReplyPageModule {}
