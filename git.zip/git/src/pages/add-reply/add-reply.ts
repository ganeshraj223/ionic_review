import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { ViewController } from 'ionic-angular';
/**
 * Generated class for the AddReplyPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-add-reply',
  templateUrl: 'add-reply.html',
})
export class AddReplyPage {

  reply: any;
  constructor(public navCtrl: NavController, public navParams: NavParams, public viewCtrl: ViewController) {
  }
  save(): void {

    let review = {
      reply: this.reply,
      status: 'reply'
    };
    console.log(review, 'review');
    this.viewCtrl.dismiss(review);

  }
  ionViewDidLoad() {
    console.log('ionViewDidLoad AddReplyPage');
  }

}
