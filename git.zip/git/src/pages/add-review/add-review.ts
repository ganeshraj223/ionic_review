import { Component } from '@angular/core';
import { ViewController } from 'ionic-angular';

@Component({
  selector: 'add-review-page',
  templateUrl: 'add-review.html'
})
export class AddReviewPage {

  title: any;
  description: any;
  rating: any;
  name: any;
  status: any;

  constructor(public viewCtrl: ViewController) {

  }

  save(): void {

    let review = {
      title: this.title,
      description: this.description,
      rating: this.rating,
      name: this.name,
      status: 'review'
    };
    console.log(review, 'review');
    this.viewCtrl.dismiss(review);

  }

  close(): void {
    this.viewCtrl.dismiss();
  }
}